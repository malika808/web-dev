// === Переключение темы ===
const toggleBtn = document.getElementById('toggle-theme');
toggleBtn.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
});

// === Гамбургер-меню ===
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('nav-links');

hamburger.addEventListener('click', () => {
  navLinks.classList.toggle('active');
});

// === Валидация формы ===
const form = document.getElementById('contact-form');
const response = document.getElementById('form-response');

form.addEventListener('submit', (e) => {
  e.preventDefault();

  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const message = document.getElementById('message').value.trim();

  if (!name || !email || !message) {
    response.textContent = "Please fill in all fields.";
    response.style.color = "red";
    return;
  }

  if (!email.includes("@")) {
    response.textContent = "Enter a valid email address.";
    response.style.color = "red";
    return;
  }

  response.textContent = "Message sent successfully!";
  response.style.color = "lightgreen";
  form.reset();
});
